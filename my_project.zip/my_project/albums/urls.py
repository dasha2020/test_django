from django.urls import path
from . import views
from .views import *

urlpatterns = [
    #path('students/', views.show_students, name='show_students'),
    #path('home/', views.home, name='home'),
    #path('get_txt_students/', views.get_txt_students, name='get_txt_students'),
    #path('get_txt_teachers/', views.get_txt_teachers, name='get_txt_teachers'),
    #path('get_txt_subjects/', views.get_txt_subjects, name='get_txt_subjects'),
    #path('get_txt_classes/', views.get_txt_classes, name='get_txt_classes'),
    #path('teachers/', views.show_teachers, name='show_teachers'),
    #path('subjects/', views.show_subjects, name='show_subjects'),
    #path('class/', views.show_classes, name='show_classes'),
    #path('get_excel_classes/', views.get_excel_classes, name='get_excel_classes'),
    #path('get_excel_subjects/', views.get_excel_subjects, name='get_excel_subjects'),
    #path('get_excel_teachers/', views.get_excel_teachers, name='get_excel_teachers'),
    #path('get_excel_students/', views.get_excel_students, name='get_excel_students'),
    #path('add_student/', views.add_student, name='add_student'),
    #path('add_teacher/', views.add_teacher, name='add_teacher'),
    #path('add_subject/', views.add_subject, name='add_subject'),
    #path('add_class/', views.add_class, name='add_class'),

    #path('edit_student/<int:student_id>/', views.edit_student, name='edit_student'),
    #path('edit_teacher/<int:teacher_id>/', views.edit_teacher, name='edit_teacher'),
    #path('edit_subject/<int:subject_id>/', views.edit_subject, name='edit_subject'),
    #path('edit_class/<int:class_id>/', views.edit_class, name='edit_class'),

    #path('delete_student/<int:student_id>/', views.delete_student, name='delete_student'),
    #path('delete_teacher/<int:teacher_id>/', views.delete_teacher, name='delete_teacher'),
    #path('delete_subject/<int:subject_id>/', views.delete_subject, name='delete_subject'),
    #path('delete_class/<int:class_id>/', views.delete_class, name='delete_class'),

    #path('edit_list_student/', views.edit_list_student, name='edit_list_student'),
    #path('edit_list_teacher/', views.edit_list_teacher, name='edit_list_teacher'),
    #path('edit_list_subject/', views.edit_list_subject, name='edit_list_subject'),
    #path('edit_list_class/', views.edit_list_class, name='edit_list_class'),

    #path('delete_list_student/', views.delete_list_student, name='delete_list_student'),
    #path('delete_list_teacher/', views.delete_list_teacher, name='delete_list_teacher'),
    #path('delete_list_subject/', views.delete_list_subject, name='delete_list_subject'),
    #path('delete_list_class/', views.delete_list_class, name='delete_list_class'),

    #classes

    path('students/', StudentView.as_view(), name='show_students'),
    path('teachers/', TeachersShow.as_view(), name='show_teachers'),
    path('subjects/', SubjectsShow.as_view(), name='show_subjects'),
    path('class/', ClassShow.as_view(), name='show_classes'),
    path('home/', HomeShow.as_view(), name='home'),
    path('get_txt_students/', StudentsTxtDownload.as_view(), name='get_txt_students'),
    path('get_txt_teachers/', TeachersTxtDownload.as_view(), name='get_txt_teachers'),
    path('get_txt_subjects/', SubjectsTxtDownload.as_view(), name='get_txt_subjects'),
    path('get_txt_classes/', ClassTxtDownload.as_view(), name='get_txt_classes'),
    path('get_excel_classes/', StudentsExcelDownload.as_view(), name='get_excel_classes'),
    path('get_excel_subjects/', TeachersExcelDownload.as_view(), name='get_excel_subjects'),
    path('get_excel_teachers/', SubjectsExcelDownload.as_view(), name='get_excel_teachers'),
    path('get_excel_students/', ClassExcelDownload.as_view(), name='get_excel_students'),

    path('add_student/', StudentView.as_view(), name='add_student'),
    path('add_teacher/', Add_Teacher.as_view(), name='add_teacher'),
    path('add_subject/', Add_Subject.as_view(), name='add_subject'),
    path('add_class/', Add_Class.as_view(), name='add_class'),

    path('edit_student/<int:student_id>/', StudentView.as_view(), name='edit_student'),
    path('edit_teacher/<int:teacher_id>/', Edit_Teacher.as_view(), name='edit_teacher'),
    path('edit_subject/<int:subject_id>/', Edit_Subject.as_view(), name='edit_subject'),
    path('edit_class/<int:class_id>/', Edit_Class.as_view(), name='edit_class'),

    path('delete_student/<int:student_id>/', StudentView.as_view(), name='delete_student'),
    path('delete_teacher/<int:teacher_id>/', Delete_Teacher.as_view(), name='delete_teacher'),
    path('delete_subject/<int:subject_id>/', Delete_Subject.as_view(), name='delete_subject'),
    path('delete_class/<int:class_id>/', Delete_Class.as_view(), name='delete_class'),

    path('edit_list_student/', Edit_List_Students.as_view(), name='edit_list_student'),
    path('edit_list_teacher/', Edit_List_Teachers.as_view(), name='edit_list_teacher'),
    path('edit_list_subject/', Edit_List_Subjects.as_view(), name='edit_list_subject'),
    path('edit_list_class/', Edit_List_Class.as_view(), name='edit_list_class'),

    path('delete_list_student/', Delete_List_Students.as_view(), name='delete_list_student'),
    path('delete_list_teacher/', Delete_List_Teachers.as_view(), name='delete_list_teacher'),
    path('delete_list_subject/', Delete_List_Subjects.as_view(), name='delete_list_subject'),
    path('delete_list_class/', Delete_List_Class.as_view(), name='delete_list_class'),
]
