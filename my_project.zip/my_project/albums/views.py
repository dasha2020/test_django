from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from albums.models import Student, Teacher, Subject, Class
import xlsxwriter
from django.contrib import messages
from django.db import IntegrityError
from django.views.generic.base import TemplateView, View
from django.urls import reverse

# Create your views here.

grades = Class.objects.all()
subjects = Subject.objects.all()

class StudentView(TemplateView):

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        return context
    
    def show_students(self, request):
        students = Student.objects.select_related('grade').all()
        context = self.get_context_data(students=students)
        return render(request, 'index.html', context)

    def create(self, request):
        if request.method == "POST":
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            age = request.POST.get('age')
            grade = request.POST.get('grade')

            grade = Class.objects.get(grade=grade)

            student = Student(first_name=first_name, last_name=last_name, age=age, grade=grade)

            try:
                student.save() 
                messages.success(request, 'Student created successfully!')
            except IntegrityError as e:
                messages.error(request, f"Error: {str(e)}")
            
            return HttpResponseRedirect(reverse('add_student'))
        else:
            context = self.get_context_data(grades=grades)
            return render(request, 'add_student.html', context)


    def update(self, request, student_id):
        student = Student.objects.get(id=student_id)
        
        if request.method == "POST":
            student = Student.objects.get(id=student_id)
            student.first_name = request.POST.get('first_name')
            student.last_name = request.POST.get('last_name')
            student.age = request.POST.get('age')
            grade = request.POST.get('grade')
            new_grade = Class.objects.get(grade=grade)
            student.grade = new_grade
            student.save()
            
            return HttpResponseRedirect(reverse('edit_student'))  

        context = self.get_context_data(classes=grades, student=student)
        return render(request, 'edit_student.html', context)

        

    def delete(self, request, student_id):
        student = Student.objects.get(id=student_id)
        
        if request.method == "POST":
            student.delete()
            return HttpResponseRedirect(reverse('delete_student'))
        else:
            context = self.get_context_data(classes=grades, student=student)
            return render(request, 'delete_student.html', context)
        

class StudentsShow(TemplateView):
    template_name = 'index.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["students"] = Student.objects.select_related('grade').all()
        return context
    
class TeachersShow(TemplateView):
    template_name = 'teachers.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["teachers"] = Teacher.objects.select_related('subject').all()
        return context
    
class SubjectsShow(TemplateView):
    template_name = 'subjects.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        subjects = Subject.objects.all()
        subject_dict = []
        for i in subjects:
            new_dict = {"sub": i, "teachers": i.teachers.all()}
            subject_dict.append(new_dict)
            print(i.teachers.all())
        context["css_file"] = 'albums/styles.css'
        context["subjects"] = subject_dict
        return context

class ClassShow(TemplateView):
    template_name = 'classes.html'
    def get_context_data(self, **kwargs):
        classes = Class.objects.all()
        class_dict = []
        for i in classes:
            new_dict = {"class": i, "students": i.students.all()}
            class_dict.append(new_dict)
            print(i.students.all())
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["classes"] = class_dict
        return context

class HomeShow(TemplateView):
    template_name = 'home.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        return context

class StudentsTxtDownload(View):
    def get(self, request, *args, **kwargs):
        response = HttpResponse(content_type='text/plain')
        response['Content-Disposition'] = 'attachment; filename="students_info.txt"'

        students = Student.objects.select_related('grade').all()

        response.write("Students List\n")
        num = 1
        for student in students:
            student_info = f"{num}. Name and Surname: {student.first_name} {student.last_name}\n Age: {student.age}\n Class: {student.grade}\n"
            response.write(student_info)
            num += 1

        return response
    

class TeachersTxtDownload(View):
    def get(self, request, *args, **kwargs):
        response = HttpResponse(content_type='text/plain')
        response['Content-Disposition'] = 'attachment; filename="teachers_info.txt"'

        teachers = Teacher.objects.select_related('subject').all()

        response.write("Teachers List\n")
        num = 1
        for teacher in teachers:
            teacher_info = f"{num}. Name and Surname: {teacher.first_name} {teacher.last_name}\n Subject: {teacher.subject}\n"
            response.write(teacher_info)
            num += 1

        return response

class SubjectsTxtDownload(View):
    def get(self, request, *args, **kwargs):
        response = HttpResponse(content_type='text/plain')
        response['Content-Disposition'] = 'attachment; filename="subjects_info.txt"'

        subjects = Subject.objects.all()

        response.write("Subjects List\n")
        num = 1
        
        for subject in subjects:
            print(subject)
            subject_info = f"{num}. Name: {subject.name}\n Description: {subject.description}\n"
            info = ''
            for i in subject.teachers.all():
                info += f"Teacher: {i.first_name} {i.last_name}\n"
            subject_info += info
            response.write(subject_info)
            num += 1

        return response

class ClassTxtDownload(View):
    def get(self, request, *args, **kwargs):
        response = HttpResponse(content_type='text/plain')
        response['Content-Disposition'] = 'attachment; filename="classes_info.txt"'

        classes = Class.objects.all()

        response.write("Classes List\n")
        num = 1
        for grade in classes:
            print(grade)
            class_info = f"{num}. Name: {grade.grade}\n Year: {grade.year}\n"
            info = ''
            for i in grade.students.all():
                info += f"Student: {i.first_name} {i.last_name}\n"
            class_info += info
            response.write(class_info)
            num += 1

        return response

class ClassExcelDownload(View):
    def get(self, request, *args, **kwargs):
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=NewExcel.xlsx'

        classes = Class.objects.all()
        class_list = []
        for i in classes:
            new_list = ["Name", i.grade]
            new_list1 = ["Year", i.year]
            info = ''
            for n in i.students.all():
                info += f"{n.first_name} {n.last_name}\n"
            new_list2 = ["Students", info]
            class_list.append(new_list)
            class_list.append(new_list1)
            class_list.append(new_list2)
        
        workbook = xlsxwriter.Workbook('NewExcel.xlsx')
        worksheet = workbook.add_worksheet()

        row = 0
        col = 0

        for i in class_list:
            header = i[0]
            value = i[1]
            worksheet.write(row, col, header)
            worksheet.write(row, col + 1, value)
            row += 1
        
        workbook.close()

        with open('NewExcel.xlsx', 'rb') as f:
            response.write(f.read())

        return response

class SubjectsExcelDownload(View):
    def get(self, request, *args, **kwargs):
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=NewExcel.xlsx'

        subjects = Subject.objects.all()
        sub_list = []
        for i in subjects:
            new_list = ["Name", i.name]
            new_list1 = ["Description", i.description]
            info = ''
            for n in i.teachers.all():
                info += f"{n.first_name} {n.last_name}\n"
            new_list2 = ["Teachers", info]
            sub_list.append(new_list)
            sub_list.append(new_list1)
            sub_list.append(new_list2)
        
        workbook = xlsxwriter.Workbook('NewExcel.xlsx')
        worksheet = workbook.add_worksheet()

        row = 0
        col = 0

        for i in sub_list:
            header = i[0]
            value = i[1]
            worksheet.write(row, col, header)
            worksheet.write(row, col + 1, value)
            row += 1
        
        workbook.close()

        with open('NewExcel.xlsx', 'rb') as f:
            response.write(f.read())

        return response

class StudentsExcelDownload(View):
    def get(self, request, *args, **kwargs):
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=NewExcel.xlsx'

        students = Student.objects.select_related('grade').all()
        students_list = []
        for i in students:
            new_list = ["First Name", i.first_name]
            new_list1 = ["Last Name", i.last_name]
            new_list2 = ["Age", str(i.age)]
            
            students_list.append(new_list)
            students_list.append(new_list1)
            students_list.append(new_list2)
            if i.grade != None:
                new_list3 = ["Grade", i.grade.grade]
                students_list.append(new_list3)
        
        workbook = xlsxwriter.Workbook('NewExcel.xlsx')
        worksheet = workbook.add_worksheet()

        row = 0
        col = 0

        for i in students_list:
            header = i[0]
            value = i[1]
            worksheet.write(row, col, header)
            worksheet.write(row, col + 1, value)
            row += 1
        
        workbook.close()

        with open('NewExcel.xlsx', 'rb') as f:
            response.write(f.read())

        return response

class TeachersExcelDownload(View):
    def get(self, request, *args, **kwargs):
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=NewExcel.xlsx'

        teachers = Teacher.objects.select_related('subject').all()
        teachers_list = []
        for i in teachers:
            new_list = ["First Name", i.first_name]
            new_list1 = ["Last Name", i.last_name]
            
            teachers_list.append(new_list)
            teachers_list.append(new_list1)
            if i.subject != None:
                new_list2 = ["Subject", i.subject.name]
                teachers_list.append(new_list2)
        
        workbook = xlsxwriter.Workbook('NewExcel.xlsx')
        worksheet = workbook.add_worksheet()

        row = 0
        col = 0

        for i in teachers_list:
            header = i[0]
            value = i[1]
            worksheet.write(row, col, header)
            worksheet.write(row, col + 1, value)
            row += 1
        
        workbook.close()

        with open('NewExcel.xlsx', 'rb') as f:
            response.write(f.read())

        return response

class Edit_List_Students(TemplateView):
    template_name = 'edit_list_student.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["students"] = Student.objects.select_related('grade').all()
        return context

class Edit_List_Teachers(TemplateView):
    template_name = 'edit_list_teacher.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["teachers"] = Teacher.objects.select_related('subject').all()
        return context
    
class Edit_List_Subjects(TemplateView):
    template_name = 'edit_list_subject.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        subjects = Subject.objects.all()
        context["css_file"] = 'albums/styles.css'
        context["subjects"] = subjects
        return context

class Edit_List_Class(TemplateView):
    template_name = 'edit_list_class.html'
    def get_context_data(self, **kwargs):
        classes = Class.objects.all()
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["classes"] = classes
        return context

class Delete_List_Students(TemplateView):
    template = 'delete_list_student.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["students"] = Student.objects.select_related('grade').all()
        return context

class Delete_List_Teachers(TemplateView):
    template_name = 'delete_list_teacher.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["teachers"] = Teacher.objects.select_related('subject').all()
        return context
    
class Delete_List_Subjects(TemplateView):
    template_name = 'delete_list_subject.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        subjects = Subject.objects.all()
        context["css_file"] = 'albums/styles.css'
        context["subjects"] = subjects
        return context

class Delete_List_Class(TemplateView):
    template_name = 'delete_list_class.html'
    def get_context_data(self, **kwargs):
        classes = Class.objects.all()
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["classes"] = classes
        return context

class Add_Student(TemplateView):
    template_name = 'add_student.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["grades"] = grades
        return context
    def post(self, request, *args, **kwargs):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        age = request.POST.get('age')
        grade = request.POST.get('grade')

        grade = Class.objects.get(grade=grade)

        student = Student(first_name=first_name, last_name=last_name, age=age, grade=grade)

        try:
            student.save() 
            messages.success(request, 'Student created successfully!')
        except IntegrityError as e:
            messages.error(request, f"Error: {str(e)}")
        
        return HttpResponseRedirect(reverse('add_student'))

        

class Add_Teacher(TemplateView):
    template_name = 'add_teacher.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["subjects"] = subjects
        return context
    def post(self, request, *args, **kwargs):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        subject = request.POST.get('subject')

        subject = Subject.objects.get(name=subject)

        teacher = Teacher(first_name=first_name, last_name=last_name, subject=subject)

        try:
            teacher.save() 
            messages.success(request, 'Teacher created successfully!')
        except IntegrityError as e:
            messages.error(request, f"Error: {str(e)}")
        
        return HttpResponseRedirect(reverse('add_teacher'))
    
class Add_Subject(TemplateView):
    template_name = 'add_subject.html'
    def get_context_data(self, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        return context
    def post(self, request, *args, **kwargs):
        name = request.POST.get('name')
        description = request.POST.get('description')
        subject = Subject(name=name, description=description)
        subject.save()
        
        return HttpResponseRedirect(reverse('add_subject'))

class Add_Class(TemplateView):
    template_name = 'add_class.html'
    def get_context_data(self, **kwargs):
        classes = Class.objects.all()
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["classes"] = classes
        return context
    def post(self, request, *args, **kwargs):
        name = request.POST.get('class_name')
        year = request.POST.get('year')

        grade = Class(grade=name, year=year)
        print(grade)

        try:
            grade.save() 
            messages.success(request, 'Grade created successfully!')
        except IntegrityError as e:
            messages.error(request, f"Error: {str(e)}")
        
        return HttpResponseRedirect(reverse('add_class'))
    
class Edit_Student(TemplateView):
    template_name = 'edit_student.html'
    def get_context_data(self, student_id, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["student"] = Student.objects.get(id=student_id)
        context["classes"] = grades
        return context
        
    def post(self, request, student_id, *args, **kwargs):
        student = Student.objects.get(id=student_id)
        student.first_name = request.POST.get('first_name')
        student.last_name = request.POST.get('last_name')
        student.age = request.POST.get('age')
        grade = request.POST.get('grade')
        new_grade = Class.objects.get(grade=grade)
        student.grade = new_grade
        student.save()
        
        return HttpResponseRedirect(reverse('edit_student'))

        

class Edit_Teacher(TemplateView):
    template_name = 'edit_teacher.html'
    def get_context_data(self, teacher_id, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["teacher"] = Teacher.objects.get(id=teacher_id)
        context["subjects"] = subjects
        return context
    def post(self, request, teacher_id, *args, **kwargs):
        teacher = Teacher.objects.get(id=teacher_id)
        teacher.first_name = request.POST.get('first_name')
        teacher.last_name = request.POST.get('last_name')
        subject = request.POST.get('subject')
        new_subject = Subject.objects.get(name=subject)
        teacher.subject = new_subject
        teacher.save()
        
        return HttpResponseRedirect(reverse('edit_teacher'))
    
class Edit_Subject(TemplateView):
    template_name = 'edit_subject.html'
    def get_context_data(self, subject_id, **kwargs):
        context =  super().get_context_data(**kwargs)
        subjects = Subject.objects.all()
        context["css_file"] = 'albums/styles.css'
        context["subject"] = Subject.objects.get(id=subject_id)
        return context
    def post(self, request, subject_id, *args, **kwargs):
        subject = Subject.objects.get(id=subject_id)
        subject.name = request.POST.get('name')
        subject.description = request.POST.get('description')
        subject.save()
        
        return HttpResponseRedirect(reverse('edit_subject'))

class Edit_Class(TemplateView):
    template_name = 'edit_class.html'
    def get_context_data(self, class_id, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["grade"] = Class.objects.get(id=class_id)
        return context
    def post(self, request, class_id, *args, **kwargs):
        grade = Class.objects.get(id=class_id)
        grade.grade = request.POST.get('grade')
        grade.year = request.POST.get('year')
        grade.save()
        
        return HttpResponseRedirect(reverse('edit_class'))

class Delete_Student(TemplateView):
    template_name = 'delete_student.html'
    def get_context_data(self, student_id, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["student"] = Student.objects.get(id=student_id)
        context["classes"] = grades
        return context
        
    def post(self, request, student_id, *args, **kwargs):
        student = Student.objects.get(id=student_id)
        student.delete()
        
        return HttpResponseRedirect(reverse('delete_student'))

        

class Delete_Teacher(TemplateView):
    template_name = 'delete_teacher.html'
    def get_context_data(self, teacher_id, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["teacher"] = Teacher.objects.get(id=teacher_id)
        context["subjects"] = subjects
        return context
    def post(self, request, teacher_id, *args, **kwargs):
        teacher = Teacher.objects.get(id=teacher_id)
        teacher.delete()
        
        return HttpResponseRedirect(reverse('delete_teacher'))
    
class Delete_Subject(TemplateView):
    template_name = 'delete_subject.html'
    def get_context_data(self, subject_id, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["subject"] = Subject.objects.get(id=subject_id)
        return context
    def post(self, request, subject_id, *args, **kwargs):
        subject = Subject.objects.get(id=subject_id)
        subject.delete()
        
        return HttpResponseRedirect(reverse('delete_subject'))

class Delete_Class(TemplateView):
    template_name = 'delete_class.html'
    def get_context_data(self, class_id, **kwargs):
        context =  super().get_context_data(**kwargs)
        context["css_file"] = 'albums/styles.css'
        context["grade"] = Class.objects.get(id=class_id)
        return context
    def post(self, request, class_id, *args, **kwargs):
        grade = Class.objects.get(id=class_id)
        grade.delete()
        
        return HttpResponseRedirect(reverse('delete_class'))



